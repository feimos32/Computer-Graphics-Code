#include <stdlib.h>
// Note that the __glut*WithExit routines should NEVER be called directly.
// To avoid the atexit workaround, #define GLUT_DISABLE_ATEXIT_HACK.
#define GLUT_DISABLE_ATEXIT_HACK
#include "glut.h"
#include<gl/glu.h>
#include<gl/gl.h>
#include "vec3.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "time.h"
inline double getRandom() {
	return rand() / (RAND_MAX + 1.0);
}

#define WIDTH 800
#define HEIGHT 800
#define M_PI 3.14159265359


void reShape(int width, int height);
void myMovedMouse(int x, int y);
void myMouse(int button, int state, int x, int y);
void display(void);
void drawCoordinate(void);
void processNormalKeys(unsigned char key, int x, int y);
void drawObject(float, float);

void drawWorld(void) {
	drawCoordinate();
	drawObject(100.0, 45.0);
}

#include "PhotonMap.h"
PhotonMap m_PhotonMap;
Nearestphotons m_Nearestphotons;

int main(int argc, char **argv) {

	srand(time(NULL));

	m_PhotonMap.readPhotonFromTxtFile();
	m_PhotonMap.balance();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(WIDTH, HEIGHT);
	glutInitWindowPosition(150, 100);
	glutCreateWindow("Feimos");

	glViewport(0, 0, WIDTH, HEIGHT);
	glEnable(GL_DEPTH_TEST);
	glutDisplayFunc(display);
	glutReshapeFunc(reShape);
	glutMouseFunc(myMouse);
	glutMotionFunc(myMovedMouse);
	glutKeyboardFunc(processNormalKeys);
	glutMainLoop();
	return 0;
}


void reShape(int width, int height) {
	glViewport(0, 0, width, height);
}

//�ж��Ƿ��µ�flag
int flag = 0;
void myMouse(int button, int state, int x, int y) {
	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON)
		{
			display();
			flag = 1;
		}
	}
	else if (state == GLUT_UP) {
		if (button == GLUT_LEFT_BUTTON) {
			display();
			flag = 0;
		}
	}
}
void myMovedMouse(int x, int y) {
	if (flag == 1)
	{
		display();
	}
}
void processNormalKeys(unsigned char key, int x, int y)
{
	if (key == 27)
		exit(0);
}

void display(void) {
	glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
	glLineWidth(1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, (double)HEIGHT / (double)WIDTH, 0.1, 100);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//�ڶ�����z     
	gluLookAt(1.5, 2.2, -5, 
		1.5, 1.8, 0.0 + 1.0, 0.0, 1, 0.0);
	//��һ���� ����ͷ �ڶ����� һ��ͷ  �������� ����ͷ
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3d(1.0, 0, 0);

	drawWorld();

	glutSwapBuffers();
}
void drawCoordinate(void) {

	glPolygonMode(GL_FRONT, GL_FILL); // ��������Ϊ���ģʽ
	glPolygonMode(GL_BACK, GL_FILL); // ��������Ϊ���ģʽ
	glFrontFace(GL_CCW);              // ������ʱ�뷽��Ϊ����
	glBegin(GL_POLYGON);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(2.0f, 0.0f, 0.0f); //x
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(-2.0f, 0.0f, 0.0f); //x
	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 2.0f, 0.0f); //y
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, -2.0f, 0.0f); //y
	glColor3f(0.0, 0.0, 1.0);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, 2.0f); //z
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, -2.0f); //z

	glEnd();

	glColor3f(1.0, 0.0, 0.0);
	glPushMatrix(); //x��
	glTranslatef(2.0, 0.0f, 0.0f);
	glRotatef(90.0, 0.0, 1.0, 0.0);
	glScalef(0.2, 0.2, 0.2);
	glutSolidCone(0.4, 1.0, 30, 30);
	glPopMatrix();
	glColor3f(0.0, 1.0, 0.0);
	glPushMatrix(); //y��
	glTranslatef(0.0, 2.0f, 0.0f);
	glRotatef(-90.0, 1.0, 0.0, 0.0);
	glScalef(0.2, 0.2, 0.2);
	glutSolidCone(0.4, 1.0, 30, 30);
	glPopMatrix();
	glColor3f(0.0, 0.0, 1.0);
	glPushMatrix(); // z��
	glTranslatef(0.0, 0.0f, 2.0f);
	glRotatef(0.0, 0.0, 0.0, 1.0);
	glScalef(0.2, 0.2, 0.2);
	glutSolidCone(0.4, 1.0, 30, 30);
	glPopMatrix();

}

int searchIndex = 0;
void drawObject(float x_rotate = 0.0, float y_rotate = 0.0) {

	glColor3f(0.0, 0.5, 0.0);
	for (int i = 0; i < m_PhotonMap.PhotonNum; i++) {
		glPushMatrix();
		glTranslatef(m_PhotonMap.mPhoton[i].Pos[0] / 2.0,
			m_PhotonMap.mPhoton[i].Pos[1] / 2.0, m_PhotonMap.mPhoton[i].Pos[2] / 2.0);
		glutSolidSphere(0.01, 20, 20);
		glPopMatrix();
	}

	// ���ѡ��һ���㣬Ȼ����Ѱ���ܱߵ�
	searchIndex = getRandom() * m_PhotonMap.PhotonNum;
	m_PhotonMap.getNearestPhotons(m_Nearestphotons, m_PhotonMap.mPhoton[searchIndex].Pos, 0.6, 100);

	glColor3f(0.7, 0.0, 0.0);
	for (int i = 1; i < m_Nearestphotons.found; i++) {
		glPushMatrix();
		glTranslatef(
			m_Nearestphotons.photons[i]->Pos.e[0] / 2.0,
			m_Nearestphotons.photons[i]->Pos.e[1] / 2.0, 
			m_Nearestphotons.photons[i]->Pos.e[2] / 2.0);
		glutSolidSphere(0.02, 20, 20);
		glPopMatrix();

	}


}

















